Zadanie NUM6

Zawartość:
-Sprawozdanie w pliku NUM6.pdf
-Kod źródłowy napisany w języku Python (wywoływany za pomocą funkcji python NUM6.py).
 Kod wykorzystuje biblioteki:   math
				random
				matplotlib (tylko do wygenerowania wykresow)
				scipy.linalg (tylko do sprawdzenia wyników)
			
