Zadanie NUM5

Zawartość:
-Sprawozdanie w pliku NUM5.pdf
-Kod źródłowy napisany w języku Python (wywoływany za pomocą funkcji python NUM5.py).
 Kod wykorzystuje biblioteki:   time 
				matplotlib 
				numpy 
			
